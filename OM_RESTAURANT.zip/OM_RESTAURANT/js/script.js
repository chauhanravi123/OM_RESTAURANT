function toggleMenu() {
  const navbar = document.getElementById("navbar").querySelector("ul");
  navbar.classList.toggle("active");
}
