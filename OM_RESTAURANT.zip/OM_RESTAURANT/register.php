<?php
if (isset($_POST['submit'])) {
    include 'connection.php';

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $address = $_POST['address'];

    // Optional: Check if email or phone already exists
    $check = "SELECT * FROM users WHERE email = ? OR phone = ?";
    $stmt = mysqli_prepare($conn, $check);
    mysqli_stmt_bind_param($stmt, "ss", $email, $phone);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Email or phone already exists please try another!');</script>";
    } else {
        $query = "INSERT INTO users (name, phone, email, password, cpassword, address)
                  VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($conn, $query);
        
        if ($stmt === false) {
            die("Prepare failed: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "ssssss", $name, $phone, $email, $password, $cpassword, $address);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Registered Successfully');</script>";
            header("Location: login.php");
            exit;
        } else {
            echo "Execute failed: " . mysqli_stmt_error($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #cfa8f9ff 0%, #2575fc 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 500px;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(to right, #bf93f0ff, #2575fc);
            color: white;
            text-align: center;
            padding: 25px 20px;
        }

        .header h2 {
            font-weight: 600;
            font-size: 28px;
        }

        .form-container {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }

        .input-with-icon {
            position: relative;
        }

        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6a11cb;
        }

        .input-with-icon input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .input-with-icon input:focus {
            border-color: #6a11cb;
            box-shadow: 0 0 0 2px rgba(106, 17, 203, 0.2);
            outline: none;
        }

        .btn {
            background: linear-gradient(to right, #6a11cb, #2575fc);
            color: white;
            border: none;
            padding: 14px 20px;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(106, 17, 203, 0.3);
        }

        .btn:hover {
            background: linear-gradient(to right, #5809b5, #1c64e0);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(106, 17, 203, 0.4);
        }

        .btn:active {
            transform: translateY(0);
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            color: #666;
            font-size: 15px;
        }

        .login-link a {
            color: #6a11cb;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .login-link a:hover {
            color: #2575fc;
            text-decoration: underline;
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #777;
        }

        @media (max-width: 576px) {
            .container {
                border-radius: 10px;
            }
            
            .form-container {
                padding: 20px;
            }
        }

        .error-message {
            color: #e74c3c;
            font-size: 13px;
            margin-top: 5px;
            display: none;
        }

        .input-error {
            border-color: #e74c3c !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Create Your Account</h2>
        </div>
        
        <div class="form-container">
            <form onsubmit="return register()" method="POST" action="register.php">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <div class="input-with-icon">
                        <i class="fas fa-user"></i>
                        <input type="text" id="name" name="name" placeholder="Enter your full name">
                    </div>
                    <div class="error-message" id="name-error">Please enter your name</div>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <div class="input-with-icon">
                        <i class="fas fa-phone"></i>
                        <input type="text" id="phone" name="phone" placeholder="Enter your 10-digit phone number">
                    </div>
                    <div class="error-message" id="phone-error">Please enter a valid 10-digit phone number</div>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-with-icon">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" placeholder="Enter your email address">
                    </div>
                    <div class="error-message" id="email-error">Please enter a valid email address</div>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Create a password (min. 6 characters)">
                    </div>
                    <div class="error-message" id="password-error">Password must be at least 6 characters</div>
                </div>
                
                <div class="form-group">
                    <label for="cpassword">Confirm Password</label>
                    <div class="input-with-icon">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="cpassword" name="cpassword" placeholder="Confirm your password">
                    </div>
                    <div class="error-message" id="cpassword-error">Passwords do not match</div>
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <div class="input-with-icon">
                        <i class="fas fa-home"></i>
                        <input type="text" id="address" name="address" placeholder="Enter your full address">
                    </div>
                    <div class="error-message" id="address-error">Please enter your address</div>
                </div>
                
                <button type="submit" class="btn" name="submit">Register Now</button>
                
                <div class="login-link">
                    Already have an account? <a href="login.php">Sign In</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        function register() {
            // Reset previous errors
            const errorElements = document.querySelectorAll('.error-message');
            errorElements.forEach(el => {
                el.style.display = 'none';
            });
            
            const inputs = document.querySelectorAll('input');
            inputs.forEach(input => {
                input.classList.remove('input-error');
            });
            
            // Get form values
            var name = document.getElementById("name").value.trim();
            var phone = document.getElementById("phone").value.trim();
            var email = document.getElementById("email").value.trim();
            var password = document.getElementById("password").value;
            var cpassword = document.getElementById("cpassword").value;
            var address = document.getElementById("address").value.trim();
            
            var isValid = true;
            
            // Validate name
            if (name === "") {
                document.getElementById("name-error").style.display = "block";
                document.getElementById("name").classList.add("input-error");
                isValid = false;
            }
            
            // Validate phone
            if (phone === "" || phone.length !== 10 || isNaN(phone)) {
                document.getElementById("phone-error").style.display = "block";
                document.getElementById("phone").classList.add("input-error");
                isValid = false;
            }
            
            // Validate email
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                document.getElementById("email-error").style.display = "block";
                document.getElementById("email").classList.add("input-error");
                isValid = false;
            }
            
            // Validate password
            if (password.length < 6) {
                document.getElementById("password-error").style.display = "block";
                document.getElementById("password").classList.add("input-error");
                isValid = false;
            }
            
            // Validate confirm password
            if (password !== cpassword) {
                document.getElementById("cpassword-error").style.display = "block";
                document.getElementById("cpassword").classList.add("input-error");
                isValid = false;
            }
            
            // Validate address
            if (address === "") {
                document.getElementById("address-error").style.display = "block";
                document.getElementById("address").classList.add("input-error");
                isValid = false;
            }
            
            if (!isValid) {
                return false;
            }
            
            return true;
        }
        
        // Password visibility toggle
        document.getElementById('password-toggle').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        document.getElementById('cpassword-toggle').addEventListener('click', function() {
            const cpasswordInput = document.getElementById('cpassword');
            const icon = this.querySelector('i');
            
            if (cpasswordInput.type === 'password') {
                cpasswordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                cpasswordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    </script>
</body>
</html>