-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 03, 2025 at 11:32 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `om_restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `name`, `email`, `password`, `date`) VALUES
(1, 'jay', 'jay@gmail.com', 'jay@123', '2025-07-03 09:22:42.000000'),
(2, 'Jaydip', 'jaydip@123gmail.com', 'jaydip@123', '2025-09-09 16:25:15.000000');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `number`, `email`, `message`, `date`) VALUES
(1, 'jaydip', '9234567890', 'jaydip@gmail.com', 'How many items avalible in your restaurant.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int NOT NULL,
  `item_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `descrption` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `img` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `price` float NOT NULL,
  `category` varchar(250) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `item_name`, `descrption`, `img`, `price`, `category`) VALUES
(1, 'Kaju-Katri', '250G Kaju-katri', 'uploads/kaju-katri.webp', 250, 'Sweet'),
(2, 'Kathiyawadi Thali', '5-Rotali ,2-sabji, 1-dalfry,1-rice,1-sweet,1-papad.', 'uploads/gujrtitahali.jpg', 199, 'Gujrati'),
(3, 'Masala Dhosa', 'Masala Dhosa, Butter milk, Idali-sambhar.', 'uploads/south-indian.jpg', 150, 'South-Indian'),
(4, 'Pani-puri', '8-pani puri', 'uploads/Pani-puri.jpg', 25, 'Fast-Food'),
(5, 'Gulab Jamun', '500G Gulab-Jamun', 'uploads/gulab jamun.webp', 150, 'Sweet'),
(6, 'Kaju Butter Masala', '250G-kaju Butter Masala ', 'uploads/kaju butter masala image.webp', 150, 'Punjabi'),
(7, 'Butter-Nan', '3-Butter Nan', 'uploads/nan.webp', 150, 'Punjabi'),
(8, 'Punjabi Thali', '3-Butter Nan, 1-Sabji, 1-Buttermilk, 1-Papad.', 'uploads/punjabi.jpg', 250, 'Punjabi'),
(9, 'Kachhi-Dabeli', '1-Dabeli', 'uploads/Kutchi-Dabeli-8.webp', 30, 'Fast-Food'),
(10, 'Chapdi-Undhiyu', '4-chapdi, 1-undhiyu', 'uploads/Chapdi-undhiyu-WS-1-696x696.jpg', 150, 'Gujrati'),
(11, 'Rajbhog-Shrikhand', '500G Rajbhog Shrikhand', 'uploads/shrikhand', 150, 'Sweet');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `customer_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL,
  `items` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `total` float NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date` datetime(6) NOT NULL,
  `user_id` int NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_name`, `phone`, `address`, `items`, `total`, `status`, `date`, `user_id`, `payment_method`) VALUES
(1, 'Jaydip', '9824323564', 'Bapa sitaram chowk, Raiya road ,Rajkot.', '[{\"product_id\":\"1\",\"name\":\"Kaju-Katri\",\"price\":\"250\",\"quantity\":1},{\"product_id\":\"11\",\"name\":\"Rajbhog-Shrikhand\",\"price\":\"150\",\"quantity\":1},{\"product_id\":\"2\",\"name\":\"Kathiyawadi Thali\",\"price\":\"199\",\"quantity\":1}]', 599, 'delivered', '2025-11-03 11:08:43.000000', 1, 'COD'),
(2, 'Jaydip', '9824323564', 'Bapa sitaram chowk, Raiya road ,Rajkot.', '[{\"product_id\":\"3\",\"name\":\"Masala Dhosa\",\"price\":\"150\",\"quantity\":1}]', 150, 'processing', '2025-11-03 11:09:02.000000', 1, 'COD'),
(3, 'Yogesh', '9824223776', 'Astron chowk, Rajkot .', '[{\"product_id\":\"5\",\"name\":\"Gulab Jamun\",\"price\":\"150\",\"quantity\":1},{\"product_id\":\"7\",\"name\":\"Butter-Nan\",\"price\":\"150\",\"quantity\":1},{\"product_id\":\"6\",\"name\":\"Kaju Butter Masala\",\"price\":\"150\",\"quantity\":1}]', 450, 'delivered', '2025-11-03 11:10:31.000000', 2, 'COD'),
(4, 'Bhavik Rathod', '9824323564', 'Bapa sitaram chowk, Raiya road ,Rajkot.', '[{\"product_id\":\"8\",\"name\":\"Punjabi Thali\",\"price\":\"250\",\"quantity\":1}]', 250, 'cancelled', '2025-11-03 11:11:32.000000', 3, 'COD'),
(5, 'Bhavik Rathod', '9824323564', 'Bapa sitaram chowk, Raiya road ,Rajkot.', '[{\"product_id\":\"10\",\"name\":\"Chapdi-Undhiyu\",\"price\":\"150\",\"quantity\":2},{\"product_id\":\"1\",\"name\":\"Kaju-Katri\",\"price\":\"250\",\"quantity\":1}]', 550, 'delivered', '2025-11-03 11:12:14.000000', 3, 'COD');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `rs_id` int NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL,
  `Guests` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`rs_id`, `customer_name`, `contact`, `date`, `time`, `Guests`) VALUES
(1, 'Jaydip', '0', '2025-08-03', '08:15:30.000000', 21),
(2, 'Yogesh Parmar', '9926741301', '2025-08-03', '10:15:00.000000', 29),
(3, 'JAY ', '9926741301', '2025-08-03', '09:30:00.000000', 25);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cpassword` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `password`, `cpassword`, `address`) VALUES
(1, 'jaydip', '9786756453', 'jaydip@gmail.com', 'jaydip', 'jaydip', 'Raiya chowkdi, Rajkot'),
(2, 'Yogesh', '9824223776', 'yogesh@gmail.com', 'yogesh', 'yogesh', 'Hanuman madhi, raiya road, rajkot'),
(3, 'bhavik', '9876543212', 'bhavik@gmail.com', 'bhavik', 'bhavik', 'Astron chowk,rajkot'),
(4, 'sachin', '7777884318', 'sachin@gmail.com', 'sachin', 'sachin', 'Bapa sitaram chowk,Raiya road,rajkot.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `rs_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
