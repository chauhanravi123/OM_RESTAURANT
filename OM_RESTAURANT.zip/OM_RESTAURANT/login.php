<?php
// login.php
include 'connection.php';
session_start();

$message = '';
$color = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        
        // Use password_verify if you're storing hashed passwords (recommended)
        if ($data['password'] == $password) { // replace with password_verify($password, $data['password']) if hashed
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['email'] = $data['email'];
            $_SESSION['loggedin'] = true;

            header("Location: index.php");
            exit();
        } else {
            $message = "Wrong password!";
            $color = "orange";
        }
    } else {
        $message = "Email not registered. Please register first!";
        $color = "red";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login GUI</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #b397d1ff, #8fb7fdff);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .login-box {
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 400px;
            transition: all 0.3s ease;
        }

        .login-box h2 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-weight: 600;
        }

        label {
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 6px;
            color: #333;
            display: block;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            transition: 0.3s ease;
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            border-color: #2575fc;
            outline: none;
        }

        button[type="submit"],
        .admin-button {
            width: 100%;
            padding: 12px;
            background: #2575fc;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-top: 10px;
        }

        button[type="submit"]:hover,
        .admin-button:hover {
            background: #1a5fd2;
        }

        .admin-button {
            display: inline-block;
            text-align: center;
            text-decoration: none;
            background: #6a11cb;
        }

        .admin-button:hover {
            background: #580fa5;
        }

        .message {
            margin-top: 20px;
            font-weight: 500;
            text-align: center;
        }

        .register-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }

        .register-link a {
            color: #2575fc;
            text-decoration: none;
            font-weight: 600;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .login-box {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>

<div class="login-box">
    <h2>Login</h2>
    <form method="POST" action="login.php">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Enter your email" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Enter your password" required>

        <button type="submit">Login</button>
    </form>

    <a href="admin/index.php" class="admin-button">Admin Login</a>

    <div class="register-link">
        New User? <a href="register.php">Register</a>
    </div>

    <?php if (!empty($message)): ?>
        <div class="message" style="color: <?= htmlspecialchars($color) ?>;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>
