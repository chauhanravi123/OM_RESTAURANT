<?php
session_start();
$conn = new mysqli("localhost", "root", "", "om_restaurant");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: Myorders.php");
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;

$sql = "SELECT * FROM orders WHERE user_id = $user_id ORDER BY date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Orders - Om Restaurant</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body class="container pt-5 my-5">
    <h1 class="mb-4">My Orders</h1>

    <a href="admin/menu.php" class="btn btn-primary mb-3">Back to Menu</a>

    <?php if ($result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Total (₹)</th>
                    <th>Status</th>
                    <th>Items</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['order_id']) ?></td>
                        <td><?= htmlspecialchars($row['date']) ?></td>
                        <td>₹<?= number_format($row['total'], 2) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td>
                            <ul>
                                <?php
                                $items = json_decode($row['items'], true);
                                foreach ($items as $item):
                                ?>
                                    <li><?= htmlspecialchars($item['name']) ?> x <?= $item['quantity'] ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You haven't placed any orders yet.</p>
    <?php endif; ?>

</body>
</html>
