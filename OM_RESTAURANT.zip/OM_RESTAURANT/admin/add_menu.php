<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

include('config/db.php');

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_name = $_POST['item_name'];
    $descrption = $_POST['descrption'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    // Image Upload
    $img = "";
    if ($_FILES['img']['name']) {
        $img = "uploads/" . basename($_FILES['img']['name']);
        move_uploaded_file($_FILES['img']['tmp_name'], $img);
    }

    $sql = "INSERT INTO menu_items (item_name, descrption, img, price, category)
            VALUES ('$item_name', '$descrption', '$img', '$price', '$category')";

    if ($conn->query($sql) === TRUE) {
        $message = "<div class='alert alert-success'>New menu item added successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
    }
}

// Fetch all items
$items = $conn->query("SELECT * FROM menu_items");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Menu Management - Om Restaurant</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    
    <style>
        body {
            padding-top: 80px;
        }
            .add-menu-title {
                background-color: rgb(74, 191, 220); /* Dark background */
                padding: 20px 15px;
                border-radius: 4px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                
                
            }

            .add-menu-title h2 {
                color: #ffffff;
                /* Responsive font size that scales with viewport */
                font-size: clamp(1.25rem, 2.2vw + 0.6rem, 2.25rem);
                line-height: 1.2;
                margin: 0;
                font-weight: 700;
                letter-spacing: 0.5px;
                text-transform: none;
                word-break: break-word;
            }

            .text-white {
                color: #ffffff !important;
            }

            .text-center {
                text-align: left !important;
            }

            .mb-4 {
                margin-bottom: 1rem !important;
            }

        @media (max-width: 991.98px) {
            .navbar-collapse {
                text-align: left;
            }

            .navbar-nav {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
            }

            .navbar-nav .nav-item {
                width: 100%;
            }

            .navbar-nav ul{
                margin-left:65%;
            }
            

            .navbar-nav .nav-link {
                padding-left: 1rem;
                width: 100%;
            }
        }
    </style>
</head>
<body class="container pt-3 my-3">
    <div class="add-menu-title text-white text-center mb-4">
    <h2>Add Menu</h2>
    </div>
    <!-- ✅ Navbar 
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Om Restaurant</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin"
                aria-controls="navbarAdmin" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarAdmin">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="menu.php">Menu</a>
                    </li>
                </ul>
                <span class="navbar-text">
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                </span>
            </div>
        </div>
    </nav>-->

    <!-- ✅ Message -->
    <?= isset($message) ? $message : '' ?>

    <!--<h1 class="mb-4 text-center">Om Restaurant - Menu Management</h1>-->

    <!-- ✅ Add Menu Form -->
    <form method="POST" enctype="multipart/form-data" class="mb-5 border p-4 rounded bg-light">
        <h4 class="mb-3">Add New Menu Item</h4>
        <div class="form-group mb-3">
            <label>Item Name</label>
            <input type="text" name="item_name" class="form-control" required>
        </div>
        <div class="form-group mb-3">
            <label>Description</label>
            <input type="text" name="descrption" class="form-control">
        </div>
        <div class="form-group mb-3">
            <label>Image</label>
            <input type="file" name="img" class="form-control-file">
        </div>
        <div class="form-group mb-3">
            <label>Price (₹)</label>
            <input type="number" step="0.01" name="price" class="form-control" required>
        </div>
        <div class="form-group mb-3">
            <label>Category</label>
            <input type="text" name="category" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Add Menu Item</button>
    </form>

    <!-- Bootstrap JS -->
    <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
