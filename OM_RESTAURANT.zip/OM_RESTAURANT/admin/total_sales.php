<?php
include('config/db.php');
session_start();
date_default_timezone_set('Asia/Kolkata');

// Selected period from GET or default to 'today'
$selectedPeriod = $_GET['period'] ?? 'today';

// Define date ranges
$today = date('Y-m-d');
$startOfWeek = date('Y-m-d', strtotime('monday this week'));
$endOfWeek = $today;

$startOfLastWeek = date('Y-m-d', strtotime('monday last week'));
$endOfLastWeek = date('Y-m-d', strtotime('sunday last week'));

$startOfMonth = date('Y-m-01');
$endOfMonth = $today;

$startOfLastMonth = date('Y-m-01', strtotime('first day of last month'));
$endOfLastMonth = date('Y-m-t', strtotime('last day of last month'));

$startOfYear = date('Y-01-01');
$endOfYear = $today;

// Determine start and end dates based on selected period
switch ($selectedPeriod) {
    case 'today':
        $startDate = $today;
        $endDate = $today;
        break;
    case 'current_week':
        $startDate = $startOfWeek;
        $endDate = $endOfWeek;
        break;
    case 'last_week':
        $startDate = $startOfLastWeek;
        $endDate = $endOfLastWeek;
        break;
    case 'current_month':
        $startDate = $startOfMonth;
        $endDate = $endOfMonth;
        break;
    case 'last_month':
        $startDate = $startOfLastMonth;
        $endDate = $endOfLastMonth;
        break;
    case 'current_year':
        $startDate = $startOfYear;
        $endDate = $endOfYear;
        break;
    default:
        $startDate = $today;
        $endDate = $today;
}

// Add time range to include full day
$startDateTime = $startDate . ' 00:00:00';
$endDateTime = $endDate . ' 23:59:59';

// Get total revenue using prepared statement
function getRevenue($conn, $startDateTime, $endDateTime) {
    $stmt = $conn->prepare("SELECT SUM(total) as revenue FROM orders 
                            WHERE status = 'delivered' AND date BETWEEN ? AND ?");
    $stmt->bind_param("ss", $startDateTime, $endDateTime);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['revenue'] ?? 0;
}

$revenue = getRevenue($conn, $startDateTime, $endDateTime);

// Fetch orders using prepared statement
$stmt = $conn->prepare("SELECT * FROM orders 
                        WHERE status = 'delivered' AND date BETWEEN ? AND ?
                        ORDER BY date DESC");
$stmt->bind_param("ss", $startDateTime, $endDateTime);
$stmt->execute();
$orders = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Revenue Report</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/header.css">
    <script src="../js/bootstrap.min.js"></script>
</head>

<style>
    #navbarMenu {
        margin-left: 59%;
    }
              
    
  
</style>

<body style="padding-top: 70px;">

<!--Navbar
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Om Restaurant</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMenu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarMenu">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active"><a class="nav-link" href="total_sales.php">Revenue</a></li>
                    <li class="nav-item"><a class="nav-link" href="orders.php">Orders</a></li>
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                </ul>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
            </div>
        </div>
    </nav>-->

    <div class="container">
        <h2 class="mb-4">Revenue Report</h2>

        <!-- Filter Dropdown -->
        <form method="get" class="form-inline mb-4">
            <label for="period">Select Time Period: &nbsp;</label>
            <select name="period" id="period" class="form-control mr-2">
                <option value="today" <?= $selectedPeriod == 'today' ? 'selected' : '' ?>>Today</option>
                <option value="current_week" <?= $selectedPeriod == 'current_week' ? 'selected' : '' ?>>Current Week</option>
                <option value="last_week" <?= $selectedPeriod == 'last_week' ? 'selected' : '' ?>>Last Week</option>
                <option value="current_month" <?= $selectedPeriod == 'current_month' ? 'selected' : '' ?>>Current Month</option>
                <option value="last_month" <?= $selectedPeriod == 'last_month' ? 'selected' : '' ?>>Last Month</option>
                <option value="current_year" <?= $selectedPeriod == 'current_year' ? 'selected' : '' ?>>Current Year</option>
            </select><br>
            <button type="submit" class="btn btn-primary">Filter</button>
        </form>

        <!-- Optional Debug Output -->
        <!-- <p><strong>Filtering from:</strong> <?= $startDateTime ?> <strong>to</strong> <?= $endDateTime ?></p> -->

        <!-- Revenue Display -->
        <h4>Total Revenue: ₹<?= number_format($revenue, 2) ?></h4>

        <!-- Orders Table -->
        <table class="table table-bordered table-hover mt-4">
            <thead class="thead-dark">
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Items</th>
                    <th>Total (₹)</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
    <?php if ($orders->num_rows > 0): ?>
        <?php while ($order = $orders->fetch_assoc()): ?>
            <tr>
                <td><?= $order['order_id'] ?></td>
                <td><?= htmlspecialchars($order['customer_name']) ?></td>
                <td>
                    <?php
                    $items = json_decode($order['items'], true);
                    if (is_array($items)) {
                        foreach ($items as $item) {
                            echo htmlspecialchars($item['name']) . " × ₹" . number_format($item['price'], 2) . " × " . intval($item['quantity']) . "<br>";
                        }
                    } else {
                        echo "Invalid item data";
                    }
                    ?>
                </td>
                <td><?= number_format($order['total'], 2) ?></td>
                <td><?= date("d M Y, h:i A", strtotime($order['date'])) ?></td>
            </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center">No orders found for selected period.</td></tr>
                <?php endif; ?>
            </tbody>

        </table>
    </div>
</body>
</html>
