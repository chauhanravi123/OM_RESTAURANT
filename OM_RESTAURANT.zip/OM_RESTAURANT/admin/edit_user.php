<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {

  
    // Not logged in, redirect to login page
    header('Location: index.php');
    exit;
}

include('config/db.php');

// Fetch user data by ID
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $result = $conn->query("SELECT * FROM users WHERE id = $id");

    if ($result->num_rows == 0) {
        die("User not found.");
    }

    $user = $result->fetch_assoc();
} else {
    header("Location: users.php");
    exit;
}

// Handle update
if (isset($_POST['update'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $email = $conn->real_escape_string($_POST['email']);
    $address = $conn->real_escape_string($_POST['address']);

    $updateQuery = "UPDATE users SET name='$name', phone='$phone', email='$email', address='$address' WHERE id=$id";

    if ($conn->query($updateQuery)) {
        header("Location: users.php");
        exit;
    } else {
        $error = "Update failed: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
   <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Edit User</h2>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" class="form-control" maxlength="10" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <input type="text" name="address" value="<?= htmlspecialchars($user['address']) ?>" class="form-control" required>
        </div>

        <button type="submit" name="update" class="btn btn-primary">Update User</button>
        <a href="users.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
