<?php
session_start();
include('config/db.php');

// Turn on error reporting during development (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['name'];
    $password = $_POST['password'];

    // Prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM admin WHERE name = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password); // assuming plain text (not secure — see notes)
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $_SESSION["adm_id"] = $row['adm_id'];
        $_SESSION["admin_logged_in"] = true;
        $_SESSION["username"] = $row['name'];

        header("Location: dashboard.php");
        exit; // 🔥 SUPER IMPORTANT!
    } else {
        // Safe way to show error
        $error = "Invalid Username or Password!";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>

    <!-- OPTIONAL: Bootstrap CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <style>
                body {
                    background: linear-gradient(135deg, #74ebd5, #ACB6E5);
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                }

                .login-container {
                    width: 100%;
                    max-width: 420px;
                    padding: 30px 25px;
                    background: #fff;
                    border-radius: 12px;
                    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
                    animation: fadeIn 0.6s ease-in-out;
                }

                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }

                .login-container h2 {
                    margin-bottom: 25px;
                    text-align: center;
                    color: #333;
                    font-weight: 600;
                }

                .form-control {
                    margin-bottom: 20px;
                    padding: 12px 15px;
                    border-radius: 8px;
                    border: 1px solid #ccc;
                    font-size: 16px;
                    transition: border-color 0.3s ease;
                }

                .form-control:focus {
                    outline: none;
                    border-color: #7eb2eaff;
                    box-shadow: 0 0 4px rgba(0, 123, 255, 0.4);
                }

                .btn-primary {
                    padding: 12px;
                    background-color: #007BFF;
                    border: none;
                    border-radius: 8px;
                    font-size: 16px;
                    font-weight: 500;
                    transition: background-color 0.3s ease;
                }

                .btn-primary:hover {
                    background-color: #0056b3;
                }

                .error {
                    color: red;
                    margin-top: 15px;
                    text-align: center;
                    font-size: 15px;
                    font-weight: 500;
                }

                @media (max-width: 500px) {
                    .login-container {
                        margin: 20px;
                        padding: 25px 20px;
                    }
                }


    </style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>
    <form method="post">
        <input type="text" name="name" class="form-control" required placeholder="Username">
        <input type="password" name="password" class="form-control" required placeholder="Password">
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
    <?php if (isset($error)) echo "<p class='error mt-3'>$error</p>"; ?>
</div>

</body>
</html>
