<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "om_restaurant");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all items
/*$items = $conn->query("SELECT * FROM menu_items");*/

// Build dynamic SQL query
$sql = "SELECT * FROM menu_items WHERE 1";

if (!empty($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $sql .= " AND item_name LIKE '%$search%'";
}

if (!empty($_GET['category'])) {
    $category = $conn->real_escape_string($_GET['category']);
    $sql .= " AND category = '$category'";
}

if (!empty($_GET['price_order']) && ($_GET['price_order'] === 'asc' || $_GET['price_order'] === 'desc')) {
    $sql .= " ORDER BY price " . strtoupper($_GET['price_order']);
}

$items = $conn->query($sql);

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_to_cart'])) {
        $product_id = $_POST['product_id'];
        $name = $_POST['name'];
        $price = $_POST['price'];
        $quantity = (int)$_POST['quantity'];

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        $found = false;

        // Check if item already exists in cart
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['product_id'] == $product_id) {
                $item['quantity'] += $quantity;

                // Limit quantity to 6
                if ($item['quantity'] > 6) {
                    $item['quantity'] = 6;
                }

                $found = true;
                break;
            }
        }

        // If item not in cart, add it
        if (!$found) {
            if ($quantity > 6) {
                $quantity = 6;
            }

            $_SESSION['cart'][] = [
                'product_id' => $product_id,
                'name' => $name,
                'price' => $price,
                'quantity' => $quantity
            ];
        }

        header("Location: menu.php?added=1");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - Om Restaurant</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #c52d2f;
            --secondary: #e8bd56;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
        }
        form.row.g-3.mb-4 {
            background-color: #ffffff;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }

        
        body {
            background-color: #f5f5f5;
            padding-top: 80px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        @media (max-width: 991.98px) {
        .navbar-collapse {
            text-align: left;
        }

        .navbar-nav {
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .navbar-nav .nav-item {
            width: 100%;
        }

        .navbar-nav .nav-link {
            display: block;
            width: 100%;
            padding: 10px 0;
        }
    }

        ul{
            margin-left: 79%;
        }
        
        .page-title {
            color: var(--dark);
            margin-bottom: 2rem;
            position: relative;
            padding-bottom: 0.5rem;
            font-weight: 700;
        }
        
        .page-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background-color: var(--primary);
        }
        
        .menu-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            height: 100%;
        }
        
        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .card-img-container {
            height: 200px;
            overflow: hidden;
        }
        
        .card-img-top {
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .menu-card:hover .card-img-top {
            transform: scale(1.05);
        }
        
        .card-body {
            padding: 1.25rem;
            display: flex;
            flex-direction: column;
        }
        
        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .card-description {
            color: #666;
            font-size: 0.9rem;
            flex-grow: 1;
            margin-bottom: 1rem;
        }
        
        .card-price {
            font-weight: bold;
            color: var(--success);
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }
        
        .card-category {
            background-color: var(--secondary);
            color: var(--dark);
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            display: inline-block;
            margin-bottom: 1rem;
        }
        
        .quantity-controls {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        }
        
        .quantity-btn {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color:rgba(12, 206, 240, 1);
            color: white;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .quantity-btn:hover {
            background: #8b8a8aff;
        }
        
        .quantity-input {
            width: 40px;
            height: 30px;
            text-align: center;
            margin: 0 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .add-to-cart-btn {
            background-color: rgba(12, 206, 240, 1);
            border: none;
            color: white;
            padding: 0.5rem;
            border-radius: 6px;
            font-weight: 600;
            transition: background 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .add-to-cart-btn:hover {
            background-color: #8a8a8adf;
        }
        
        .cart-badge {
            position: fixed;
            top: 15px;
            right: 15px;
            background: var(--primary);
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            z-index: 1000;
        }
        
        .cart-floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 100;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: rgba(8, 183, 236, 0.91);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s;
        }
        
        .cart-floating-btn:hover {
            transform: scale(1.1);
            color: white;
        }
        
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success);
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 1050;
            display: none;
        }
        
        @media (max-width: 768px) {
            .menu-card {
                margin-bottom: 1.5rem;
            }
            
        }
    </style>
</head>
<body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Om Restaurant</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu"
                        aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarMenu">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                    <a class="nav-link active" href="menu.php">Menu</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="cart.php">Cart</a>
                    </li>
                    <li class="nav-item">
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                    </li>
                </ul>
                
                </div>
            </div>
        </nav>
            <form method="GET" action="menu.php" class="row g-3 mb-4">
                    <div class="col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Search by item name..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                    </div>

                    <div class="col-md-3">
                        <select name="category" class="form-select">
                            <option value="">All Categories</option>
                            <?php
                            // Get distinct categories from DB
                            $category_result = $conn->query("SELECT DISTINCT category FROM menu_items");
                            while ($cat = $category_result->fetch_assoc()):
                            ?>
                                <option value="<?= htmlspecialchars($cat['category']) ?>" <?= (isset($_GET['category']) && $_GET['category'] == $cat['category']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['category']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <select name="price_order" class="form-select">
                            <option value="">Sort by Price</option>
                            <option value="asc" <?= (isset($_GET['price_order']) && $_GET['price_order'] == 'asc') ? 'selected' : '' ?>>Low to High</option>
                            <option value="desc" <?= (isset($_GET['price_order']) && $_GET['price_order'] == 'desc') ? 'selected' : '' ?>>High to Low</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">Filter</button>
                    </div>
            </form>


    <div class="container">
        <h1 class="page-title">Our Menu</h1>
        
        <?php if (isset($_GET['added']) && $_GET['added'] == 1): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Item added to cart successfully!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <?php while($row = $items->fetch_assoc()): ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="menu-card card">
                    <div class="card-img-container">
                        <?php if ($row['img']): ?>
                            <img src="<?= $row['img'] ?>" class="card-img-top" alt="<?= htmlspecialchars($row['item_name']) ?>">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/300x200/EFEFEF/666666?text=Food+Image" class="card-img-top" alt="No image">
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-body">
                        <span class="card-category"><?= htmlspecialchars($row['category']) ?></span>
                        <h5 class="card-title"><?= htmlspecialchars($row['item_name']) ?></h5>
                        <p class="card-description"><?= htmlspecialchars($row['descrption']) ?></p>
                        <p class="card-price">₹<?= htmlspecialchars($row['price']) ?></p>
                        
                        <form method="POST" action="" class="add-to-cart-form">
                            <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
                            <input type="hidden" name="name" value="<?= htmlspecialchars($row['item_name']) ?>">
                            <input type="hidden" name="price" value="<?= $row['price'] ?>">
                            
                            <div class="quantity-controls">
                                <button type="button" class="quantity-btn minus" onclick="updateQuantity(<?= $row['id'] ?>, -1)">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <input type="number" name="quantity" id="quantity_<?= $row['id'] ?>" class="quantity-input" value="1" min="1" max="6" readonly>
                                <button type="button" class="quantity-btn plus" onclick="updateQuantity(<?= $row['id'] ?>, 1)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            
                            <button type="submit" name="add_to_cart" class="add-to-cart-btn">
                                <i class="fas fa-cart-plus"></i> Add to Cart
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
    
    <a href="cart.php" class="cart-floating-btn">
        <i class="fas fa-shopping-cart"></i>
    </a>
    
    <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
        <div class="cart-badge"><?= count($_SESSION['cart']) ?></div>
    <?php endif; ?>
    
    <div class="notification" id="addNotification">
        Item added to cart!
    </div>

    
    
    <script>
        function updateQuantity(itemId, change) {
            const input = document.getElementById(`quantity_${itemId}`);
            let newValue = parseInt(input.value) + change;
            
            if (newValue < 1) newValue = 1;
            if (newValue > 6) newValue = 6;
            
            input.value = newValue;
        }
        
        // Show notification when item is added
        document.querySelectorAll('.add-to-cart-form').forEach(form => {
            form.addEventListener('submit', function() {
                const notification = document.getElementById('addNotification');
                notification.style.display = 'block';

                setTimeout(() => {
                    notification.style.display = 'none';
                }, 3000);
            });
        });
    </script>
</body>
    <!--<script src="../js/jquery-3.5.1.slim.min.js"></script>-->
    <script src="../js/bootstrap.bundle.min.js"></script>
</html>