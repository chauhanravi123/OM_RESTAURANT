<?php
session_start();
$conn = new mysqli("localhost", "root", "", "om_restaurant");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Remove item from cart
if (isset($_GET['remove'])) {
    $remove_index = (int)$_GET['remove'];
    if (isset($_SESSION['cart'][$remove_index])) {
        unset($_SESSION['cart'][$remove_index]);
        $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex
    }
    header("Location: cart.php");
    exit;
}

// Clear cart
if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    header("Location: cart.php");
    exit;
}
// Clear cart
if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    header("Location: cart.php");
    exit;
}

// Increase quantity (with max limit 6)
if (isset($_GET['add'])) {
    $add_index = (int)$_GET['add'];
    if (isset($_SESSION['cart'][$add_index])) {
        if ($_SESSION['cart'][$add_index]['quantity'] < 6) {
            $_SESSION['cart'][$add_index]['quantity']++;
        }
    }
    header("Location: cart.php");
    exit;
}


// Decrease quantity
if (isset($_GET['sub'])) {
    $sub_index = (int)$_GET['sub'];
    if (isset($_SESSION['cart'][$sub_index])) {
        $_SESSION['cart'][$sub_index]['quantity']--;
        if ($_SESSION['cart'][$sub_index]['quantity'] <= 0) {
            unset($_SESSION['cart'][$sub_index]); // Remove item if quantity becomes 0
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex
        }
    }
    header("Location: cart.php");
    exit;
}


// Checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php?redirect=cart.php");
        exit;
    }

    $customer_name = $conn->real_escape_string($_POST['customer_name']);
    $phone = trim($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);
    $cartItems = $_SESSION['cart'];

    // Server-side phone validation (Indian 10-digit number starting with 6-9)
    if (!preg_match('/^[6-9]\d{9}$/', $phone)) {
        $error = "Invalid phone number. Please enter a 10-digit Indian mobile number starting with 6-9.";
    }
    

    if (empty($cartItems)) {
        $error = "Cart is empty!";
    } else {
        $user_id = $_SESSION['user_id'];
        $order_id = 'ORD' . date('YmdHis') . rand(100, 999);
        $items_json = json_encode($cartItems);
        $total = 0;

        foreach ($cartItems as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        $status = 'Pending';
        $date = date('Y-m-d H:i:s');
        // Use prepared statements for security
        $stmt = $conn->prepare("INSERT INTO orders (user_id, customer_name, phone, address, items, total, status, date,payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)");
        $stmt->bind_param("issssdsss", $user_id, $customer_name, $phone, $address, $items_json, $total, $status, $date,$payment_method);

        $payment_method = isset($_POST['payment_method']) ? $conn->real_escape_string($_POST['payment_method']) : '';

        if ($payment_method !== 'COD' && $payment_method !== 'Online') {
            die("Invalid payment method selected.");
        }


        if ($stmt->execute()) {
            $_SESSION['cart'] = []; // Clear cart
            $success = "Order placed successfully! Your Order ID is <strong>$order_id</strong>";
        } else {
            $error = "Error: " . $stmt->error;
        }
       

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cart - Om Restaurant</title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
       /* Enhance navbar brand */
            .navbar-brand {
                font-weight: bold;
                font-size: 1.7rem;
                color: white !important; /* Bootstrap warning color */
            }

            /* Navbar toggle button style */
            .navbar-toggler {
                border: none;
                outline: none;
                transition: background-color 0.3s ease;
            }

            .navbar-toggler:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }

            /* Smooth dropdown for collapse */
            .navbar-collapse {
                transition: max-height 0.4s ease;
            }

            /* Mobile menu items spacing */
            .navbar-nav .nav-item {
                margin-left: 15px;
            }

            /* Mobile menu item hover effect */
            .navbar-nav .nav-link {
                padding: 8px 15px;
                transition: color 0.3s, background-color 0.3s;
                border-radius: 5px;
            }

            .navbar-nav .nav-link:hover {
                background-color: rgba(255, 255, 255, 0.1);
                color:white !important; /* Highlight color on hover */
            }

            /* Active link */
            .navbar-nav .nav-link.active {
                color:whitesmoke !important;
                font-weight: bold;
            }

            /* Button on right */
            .navbar-text .btn {
                margin-left: 10px;
            }

            /* Better spacing on small screens */
            @media (max-width: 991.98px) {
                #navbarNavCart {
                    margin-left: 0 !important;
                }

                .navbar-nav {
                    margin-top: 10px;
                }

                .navbar-nav .nav-item {
                    margin-bottom: 10px;
                }
            }


    </style>
</head>
<body class="container pt-5 my-5">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">Om Restaurant</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavCart" aria-controls="navbarNavCart" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavCart">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
                <li class="nav-item"><a class="nav-link active" href="cart.php">Cart</a></li>
                <li class="nav-item"><a class="nav-link" href="../Myorders.php">Orders</a></li>
            </ul>
            <span class="navbar-text">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                <?php else: ?>
                    <a href="../login.php" class="btn btn-outline-light btn-sm">Login</a>
                <?php endif; ?>
            </span>
        </div>
    </div>
</nav>


<h1 class="mb-4">Your Cart</h1>

<?php if (!empty($success)): ?>
    <div class="alert alert-success"><?= $success ?></div>
<?php elseif (!empty($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<?php if (empty($_SESSION['cart'])): ?>
    <p>Your cart is empty. </p><!-- <a href="menu.php">Go back to menu</a> -->
<?php else: ?>
    

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Item</th>
                <th>Price (₹)</th>
                <th>Quantity</th>
                <th>Subtotal (₹)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $total = 0;
        foreach ($_SESSION['cart'] as $index => $item):
            $subtotal = $item['price'] * $item['quantity'];
            $total += $subtotal;
        ?>
            <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= number_format($item['price'], 2) ?></td>
                <td>
                    <a href="cart.php?sub=<?= $index ?>" class="btn btn-sm btn-light">➖</a>
                    <?= $item['quantity'] ?>
                    <a href="cart.php?add=<?= $index ?>" class="btn btn-sm btn-light">➕</a>
                </td>


                <td><?= number_format($subtotal, 2) ?></td>
                <td>
                    <a href="cart.php?remove=<?= $index ?>" class="btn btn-danger btn-sm" onclick="return confirm('Remove this item?')">Remove</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <th colspan="3" class="text-right">Total</th>
            <th>₹<?= number_format($total, 2) ?></th>
            <th></th>
        </tr>
        </tbody>
    </table>
    <a href="cart.php?clear=1" class="btn btn-warning mb-3" onclick="return confirm('Clear entire cart?')">Clear Cart</a>
    <a href="menu.php" class="btn btn-primary mb-3 ml-2">Add More Items</a>

    <h3 class="mt-4">Checkout</h3>
    <?php if (!isset($_SESSION['user_id'])): ?>
        <div class="alert alert-warning">
            Please <a href="../login.php">log in</a> to proceed with checkout.
        </div>
    <?php else: ?>
        <form method="POST" onsubmit="return register()">
                <div class="form-group">
                    <label>Customer Name</label>
                    <input type="text" name="customer_name" id="customer_name" class="form-control" required>
                    <small id="name-error" class="text-danger error-message" style="display:none;">Please enter your name.</small>

                    <label>Phone</label>
                    <input type="text" id="phone" name="phone" class="form-control" required>
                    <small id="phone-error" class="text-danger error-message" style="display:none;">Please enter a valid 10-digit Indian number starting with 6-9.</small>

                    <label>Address</label>
                    <input type="text" id="address" name="address" class="form-control" required>
                    <small id="address-error" class="text-danger error-message" style="display:none;">Please enter your address.</small>
                </div>

                <label>Payment Method</label><br>
                <input type="radio" id="cod" name="payment_method" value="COD" required>
                <label for="cod">Cash on Delivery</label><br>

                <input type="radio" id="online" name="payment_method" value="Online" disabled>
                <label for="online">Online Payment (Disabled)</label><br>
                <small id="payment-error" class="text-danger error-message" style="display:none;">Please select a payment method.</small>

                <button type="submit" name="checkout" class="btn btn-success">Place Order</button>
            </form>

    <?php endif; ?>
<?php endif; ?>

<a href="menu.php" class="btn btn-secondary mt-4">Back to Menu</a>

<script>
function register() {
    // Reset previous errors
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');
    document.querySelectorAll('input').forEach(input => input.classList.remove('is-invalid'));

    var name = document.getElementById("customer_name").value.trim();
    var phone = document.getElementById("phone").value.trim();
    var address = document.getElementById("address").value.trim();
    var isValid = true;

    // Validate name
    if (name === "") {
        document.getElementById("name-error").style.display = "block";
        document.getElementById("customer_name").classList.add("is-invalid");
        isValid = false;
    }

    // Validate phone (10-digit Indian number starting with 6-9)
    var phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(phone)) {
        document.getElementById("phone-error").style.display = "block";
        document.getElementById("phone").classList.add("is-invalid");
        isValid = false;
    }

    // Validate address
    if (address === "") {
        document.getElementById("address-error").style.display = "block";
        document.getElementById("address").classList.add("is-invalid");
        isValid = false;
    }

    // Validate payment method (at least one radio selected)
    var paymentSelected = document.querySelector('input[name="payment_method"]:checked');
    if (!paymentSelected) {
        document.getElementById("payment-error").style.display = "block";
        isValid = false;
    }

    return isValid;
}
</script>

<script src="../js/bootstrap.bundle.min.js"></script>

</body>
</html>
