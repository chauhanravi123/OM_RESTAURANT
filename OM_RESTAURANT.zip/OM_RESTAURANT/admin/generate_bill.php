<?php
// generate_bill.php
include('config/db.php');

// Get order ID from URL
if (!isset($_GET['id'])) {
    die("Order ID not provided.");
}
$order_id = intval($_GET['id']);

// Fetch order from database
$result = $conn->query("SELECT * FROM orders WHERE order_id = $order_id");
if ($result->num_rows == 0) {
    die("Order not found.");
}
$order = $result->fetch_assoc();

// Parse the items field (handle JSON or plain text)
$items = [];

// Try to decode as JSON
$decoded = json_decode($order['items'], true);

if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
    // ✅ It's valid JSON
    $items = $decoded;
} else {
    // ❌ Not JSON — fallback to parsing plain string like: "Pizza x2 @250, Coke x1 @50"
    $itemLines = explode(',', $order['items']);
    foreach ($itemLines as $line) {
        if (preg_match('/^(.*) x(\d+)\s*@\s*(\d+)$/', trim($line), $matches)) {
            $items[] = [
                'name' => trim($matches[1]),
                'qty' => (int)$matches[2],
                'price' => (float)$matches[3]
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bill - Order #<?= $order_id ?></title>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }
        .bill-container {
            width: 700px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .restaurant-name {
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .bill-header {
            margin-bottom: 20px;
        }
        .total {
            font-weight: bold;
            font-size: 18px;
            text-align: right;
        }
        .btn-print {
            margin-top: 20px;
            text-align: center;
        }
        @media print {
            .btn-print {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="bill-container">
    <div class="restaurant-name">Om Restaurant</div>

    <div class="bill-header">
        <p><strong>Order Number:</strong> <?= $order['order_id'] ?></p>
        <p><strong>Customer:</strong> <?= $order['customer_name'] ?></p>
        <p><strong>Phone Number:</strong><?=$order['phone']?></p>
        <p><strong>Address:</strong><?=$order['address']?></p>
        <p><strong>Date:</strong> <?= date("d M Y, h:i A", strtotime($order['date'])) ?></p>
        <p><strong>Payment Mode:</strong><?=$order['payment_method']?></p>
        <!-- <p><strong>Status:</strong> <?= ucfirst($order['status']) ?></p> -->
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $grandTotal = 0;
            foreach ($items as $item) {
                // Check if keys exist to avoid warnings
                $name = isset($item['name']) ? $item['name'] : 'Unknown';
                $qty = isset($item['quantity']) ? $item['quantity'] : 0;
                $price = isset($item['price']) ? $item['price'] : 0;
                $lineTotal = $qty * $price;
                $grandTotal += $lineTotal;

                echo "<tr>
                        <td>{$name}</td>
                        <td>{$qty}</td>
                        <td>₹{$price}</td>
                        <td>₹{$lineTotal}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="total">
        Grand Total: ₹<?= number_format($grandTotal, 2) ?>
    </div>

    <div class="btn-print text-center">
        <button class="btn btn-success" onclick="window.print()">Print Bill</button>
        <a href="orders.php" class="btn btn-secondary">Back to Orders</a>
    </div>
</div>

</body>
</html>
