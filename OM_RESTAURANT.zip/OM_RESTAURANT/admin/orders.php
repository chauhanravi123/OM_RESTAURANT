<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

include('config/db.php');

$orders = $conn->query("SELECT * FROM orders ORDER BY order_id DESC");

if (isset($_GET['action']) && isset($_GET['id'])) {
    $orderId = intval($_GET['id']);
    $action = $_GET['action'];

    if (in_array($action, ['delivered', 'processing', 'cancelled'])) {
        $conn->query("UPDATE orders SET status='$action' WHERE order_id=$orderId");
    } elseif ($action == 'delete') {
        $conn->query("DELETE FROM orders WHERE order_id=$orderId");
    }

    header("Location: orders.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management</title>
    <h2 style="text-align: center;padding-top:2%;">Order Management</h2>
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    
    <style>
      .orders-table {
                background: #ffffff;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1); /* Soft large shadow */
                transition: box-shadow 0.3s ease;
                overflow-x: auto;
            }

            /* Table container on hover for dynamic shadow */
            .orders-table:hover {
                box-shadow: 0 12px 28px rgba(0, 0, 0, 0.15);
            }

            .table {
                margin: 0;
                border-collapse: separate;
                border-spacing: 0 8px; /* Adds spacing between rows */
            }

            .table thead th {
                background-color: #343a40;
                color: white;
                text-align: center;
                vertical-align: middle;
                font-size: 14px;
                border: none;
                padding: 12px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
            }

            .table tbody tr {
                background-color: #f9f9f9;
                border-radius: 8px;
                transition: background-color 0.3s ease, box-shadow 0.3s ease;
            }

            .table tbody tr:hover {
                background-color: #f1f1f1;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.06);
            }

            .table td {
                text-align: center;
                vertical-align: middle;
                padding: 14px;
                border: none;
                font-size: 14px;
                color: #333;
            }

            /* Order date highlight */
            .order-date {
                font-weight: 600;
                color: #007bff;
            }

            /* Buttons inside table */
            .table .btn-sm {
                font-size: 12px;
                padding: 5px 10px;
            }

            /* Dropdown actions menu */
            .dropdown-menu a {
                font-size: 14px;
            }

            /* Make the table responsive */
            @media (max-width: 768px) {
                .table-responsive {
                    overflow-x: auto;
                }

                .table td, .table th {
                    white-space: nowrap;
                }
            }

             


    </style>
</head>
<body>


<!--Navbar
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Om Restaurant</a>
    <div class="collapse navbar-collapse">
        <ul class="navbar-nav">
            <li class="nav-item active"><a class="nav-link" href="orders.php">Orders</a></li>
            <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        </ul>
        <span class="navbar-text">
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </span>
    </div>
</nav>-->

<div class="container">
    <div class="orders-table">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                    <th>Bill</th>
                </tr>
            </thead>
            <tbody>
                <?php while($order = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($order['order_id']) ?></td>
                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                    <td><?= htmlspecialchars($order['phone']) ?></td>
                    <td><?= htmlspecialchars($order['address']) ?></td>
                    <td>
                        <?php 
                        $items = json_decode($order['items'], true); 
                        if (is_array($items)) {
                            foreach ($items as $item) {
                                echo htmlspecialchars($item['name']) . " × " . intval($item['quantity']) . " x ₹" . number_format($item['price'], 2) . "<br>";
                            }
                        } else {
                            echo "Invalid item data";
                        }
                        ?>
                    </td>
                    <td>₹<?= number_format($order['total'], 2) ?></td>
                    <td><?= ucfirst(htmlspecialchars($order['status'])) ?></td>
                    <td class="order-date"><?= date("d M Y", strtotime($order['date'])) ?></td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="orderActionsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                Actions
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="orderActionsDropdown">
                                <li>
                                    <a class="dropdown-item text-success" href="?action=delivered&id=<?= $order['order_id'] ?>">
                                        <i class="bi bi-check-circle"></i> Mark as Delivered
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-warning" href="?action=processing&id=<?= $order['order_id'] ?>">
                                        <i class="bi bi-clock-history"></i> Mark as Processing
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-danger" href="?action=cancelled&id=<?= $order['order_id'] ?>">
                                        <i class="bi bi-x-circle"></i> Mark as Cancelled
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item text-danger" href="?action=delete&id=<?= $order['order_id'] ?>" onclick="return confirm('Are you sure you want to delete this order?')">
                                        <i class="bi bi-trash"></i> Delete Order
                                    </a>
                                </li>
                            </ul>
                        </div>

                    </td>
                    <td>
                        <a href="generate_bill.php?id=<?= $order['order_id'] ?>" class="btn btn-primary btn-sm mb-1">Generate Bill</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
            <script src="../js/bootstrap.bundle.min.js"></script>

            <script>
                $(function () {
                    $('[title]').tooltip();
                });
            </script>
</html>
