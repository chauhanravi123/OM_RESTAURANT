<?php

use Dom\Mysql;

session_start();


if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {

  
    // Not logged in, redirect to login page
    header('Location: index.php');
    exit;
}
$_SESSION['admin_logged_in'] = true;
//$_SESSION['name'] = $username; // must be set here

// No need to reassign session values here
include('config/db.php');
include('includes/header.php');
include('includes/footer.php');
?>

<?php



// Get recent orders
$recent_orders = $conn->query("SELECT order_id,customer_name, total, status 
                              FROM orders 
                              
                              ORDER BY date DESC LIMIT 5");

// Get upcoming reservations
$upcoming_reservations = $conn->query("SELECT rs_id,customer_name, date, Guests 
                                      FROM reservation  
                                    
                                      WHERE date >= CURDATE() 
                                      ORDER BY date ASC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Om Restaurant</title>

  <!-- Bootstrap 5 CDN -->
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
  
  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css"> 
 

  <style>
    :root {
      --primary-color: #4e73df;
      --secondary-color: #1cc88a;
      --danger-color: #e74a3b;
      --warning-color:rgb(254, 254, 15);
      --dark-color: #5a5c69;
    }
  

    
    body {
      background-color: #f8f9fc;
      padding-top: 70px;
      font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    }

    .dashboard-container {
      max-width: 1400px;
      margin: auto;
      padding: 0 15px;
    }

    .card {
      box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
      transition: transform 0.2s ease;
      border: none;
      border-radius: 0.35rem;
      margin-bottom: 1.5rem;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card-header {
      background-color: #f8f9fc;
      border-bottom: 1px solid #e3e6f0;
      padding: 1rem 1.35rem;
      font-weight: 600;
    }
    
    .card-body {
      padding: 1.25rem;
    }

    .stat-card {
      border-left: 0.25rem solid;
      transition: all 0.3s;
    }
    
    .stat-card:hover {
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    .stat-card.menu {
      border-left-color: var(--primary-color);
    }
    
    .stat-card.orders {
      border-left-color: var(--secondary-color);
    }
    
    .stat-card.reservations {
      border-left-color: var(--warning-color);
    }
    
    .stat-card.users {
      border-left-color: var(--dark-color);
    }
    
    .stat-card .stat-value {
      font-size: 1.5rem;
      font-weight: 700;
    }
    
    .stat-card .stat-label {
      font-size: 0.875rem;
      text-transform: uppercase;
      font-weight: 600;
      color: #858796;
    }
    
    .table-responsive {
      overflow-x: auto;
    }
    
    .sidebar {
      min-height: 100vh;
      background: linear-gradient(180deg, var(--primary-color) 10%, #224abe 100%);
      position: fixed;
      width: 14rem;
      top: 0;
      left: 0;
      padding-top: 4.5rem;
      transition: all 0.3s;
      z-index: 1000;
    }
    
    .sidebar .nav-link {
      color: rgba(255, 255, 255, 0.8);
      padding: 1rem;
      font-weight: 600;
      border-left: 0.25rem solid transparent;
    }
    
    .sidebar .nav-link:hover {
      color: white;
      background: rgba(255, 255, 255, 0.1);
    }
    
    .sidebar .nav-link.active {
      color: white;
      border-left-color: white;
      background: rgba(255, 255, 255, 0.1);
    }
    
    .sidebar .nav-link i {
      margin-right: 0.5rem;
    }
    
    .main-content {
      margin-left: 14rem;
      width: calc(100% - 14rem);
    }
    
    .navbar {
      padding-left:0px;
    }
    
    @media (max-width: 992px) {
      .sidebar {
        transform: translateX(-100%);
      }
      
      .sidebar.show {
        transform: translateX(0);
      }
      
      .main-content, .navbar {
        margin-left: 0;
        width: 100%;
      }
    }
    
    .sidebar-toggler {
      display: none;
    }
    
    @media (max-width: 992px) {
      .sidebar-toggler {
        display: inline-block;
      }
      
    }
    
        
  </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <div class="px-3 py-4">
    <div class="text-center text-white mb-4">
      <h5>Om Restaurant</h5>
      <small>Admin Panel</small>
    </div>
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="nav-link active" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          Dashboard
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="add_menu.php">
          <i class="fas fa-fw fa-plus-circle"></i>
          Add Menu
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_menu.php">
          <i class="fas fa-fw fa-utensils"></i>
          Manage Menu
        </a>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link" href="add_restaurant.php">
          <i class="fas fa-fw fa-coffee"></i>
          Add Restaurant
        </a> -->
      </li>
      <li class="nav-item">
        <a class="nav-link" href="orders.php">
          <i class="fas fa-fw fa-shopping-cart"></i>
          Orders
        </a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="total_sales.php">
          <i class="fas fa-money-bill-wave"></i> 
        Revenue Report 
         </a>
      </li>
    <!--  <li class="nav-item">
        <a class="nav-link" href="manage_reservation.php">
          <i class="fas fa-fw fa-calendar-alt"></i>
          Reservations
        </a>
      </li> -->
      <li class="nav-item">
        <a class="nav-link" href="users.php">
          <i class="fas fa-fw fa-users"></i>
          Users
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contactus.php">
          <i class="fa-solid fa-circle-user"></i>
          Contactus
        </a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="logout.php">
          <i class="fas fa-sign-out-alt me-2"></i>
          Logout
        </a>
      </li>

    </ul>
  </div>
</div>

<!-- Main Content -->
<div class="main-content">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <button class="btn btn-dark sidebar-toggler me-3" type="button" id="sidebarToggle">
        <i class="fas fa-bars"></i>
      </button>
      <a class="navbar-brand" href="#">Admin Dashboard</a>
      
      <div class="collapse navbar-collapse" id="navbarAdmin">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
              <i class="fas fa-user-circle me-1"></i>
              <?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              
              <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Dashboard Main -->
  <div id="dashboardOverview" class="container-fluid dashboard-container py-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800">Dashboard Overview</h1>
    </div>
    
    <!-- Stats Cards -->
    <div class="row">
      <!--Card 1: Menu Items Card -->
      <div class="col-md-4">
        <div class="card p-30" style="box-shadow:0 0 11px black;">
          <div class="media">
            <div class="media-left media media-middle">
              <span><i class="fa fa-cutlery s-s-50"></i></span>   
              </div>
              <div class="media-body media-text-right">
                <h2><?php $sql="select * from menu_items"; $result=mysqli_query($conn,$sql); echo mysqli_num_rows($result);?></h2>
                <p class="m-b-0">Menu Items</p>
              </div>
            </div>
          </div>
        </div>
      

      <!-- Card 2: Users -->
              <div class="col-md-4">
                  <div class="card p-30" style="box-shadow: 0 0 11px black;">
                      <div class="media">
                          <div class="media-left meida media-middle">
                              <span><i class="fa fa-user f-s-40"></i></span>
                          </div>
                          <div class="media-body media-text-right">
                              <h2><?php $sql="select * from users"; $result=mysqli_query($conn,$sql); echo mysqli_num_rows($result); ?></h2>
                              <p class="m-b-0">Users</p>
                          </div>
                      </div>
                  </div>
              </div>
    
      <!-- Card 3:Total  Orders Card -->
      <div class="col-md-4">
        <div class="card p-30" style="box-shadow:0 0 11px black";>
          <div class="media">
            <div class="media-left media media-middle">
                <span><i class="fa fa-shopping-cart f-s-40"></i></span>
              </div>
              <div class="media-body media-text-right">
                <h2><?php $sql="select * from orders";$result=mysqli_query($conn,$sql);echo mysqli_num_rows($result); ?></h2>
                <p class="m-b-0">Total Orders</p>
              </div>
          </div>
        </div>
      </div>

      <!-- Card 4: Pending Orders-->
      <div class="col-md-4">
        <div class="card p-30" style="box-shadow:0 0 11px black";>
          <div class="media">
            <div class="media-left media media-middle">
              <span><i class="fa fa-clock f-s-40"></i></span>
            </div>
            <div class="media-body media-text-right">
              <h2><?php $sql="select * from orders where status='pending'";$result=mysqli_query($conn,$sql);echo mysqli_num_rows($result);?></h2>
              <p class="m-b-0">Pending Orders</p>
            </div>
          </div>
        </div>
      </div>

      <!--Card 5 : Processing orders-->
      <div class="col-md-4">
        <div class="card p-30" style="box-shadow:0 0 11px black";>
          <div class="media">
            <div class="media-left media media-liddle">
              <span><i class="fa fa-spinner f-s-40"></i></span>
            </div>
            <h2><?php $sql="select * from orders where status='processing'";$result=mysqli_query($conn,$sql);echo mysqli_num_rows($result) ;?></h2>
            <p class="m-b-0">Processing Orders</p>
          </div>
        </div>
      </div>

      <!-- Cadr 6 : Delivered orders card -->
      <div class="col-md-4">
        <div class=" card p-30" style="box-shadow: 0 0 11px black";>
          <div class="media">
            <div class="media-left media media-middle">
              <span><i class="fa fa-check f-s-40"></i></span>
            </div>
            <div class="media-body media-text-right">
              <h2><?php $sql="select * from orders where status='delivered'";$result=mysqli_query($conn,$sql);echo mysqli_num_rows($result);?></h2>
              <p class="m-b-0">Delivered Orders</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Card 7 : Cancelled Orders -->
       <div class="col-md-4">
        <div class="card p-30" style="box-shadow: 0 0 11px black";>
          <div class="media">
            <div class="media-left media media-middle">
              <span><i class="fa fa-times f-s-40"></i></span>
            </div>
            <h2><?php $sql="select * from orders where status='cancelled'";$result=mysqli_query($conn,$sql);echo mysqli_num_rows($result);?></h2>
            <p class="m-b-0">Cancelled Orders</p>
          </div>
        </div>
       </div>

        <!-- Card 8: Reservations Card -->
       <div class="col-md-4">
         <div class="card p-30" style="box-shadow: 0 0 11px black";>
           <div class="media">
             <div class="media-left media media-middle">
               <span><i class="fa  fa-house f-s-40"></i></span>
            </div>
            <h2><?php $sql="select * from reservation ";$result=mysqli_query($conn,$sql);echo mysqli_num_rows($result);?></h2>
            <p class="m-b-0">Reservations</p>
          </div>
        </div>
       </div> 

            <!-- Card 9: Total Earnings -->
            <div class="col-md-4">
                <div class="card p-31" style="box-shadow: 0 0 9px black;">
                    <div class="media">
                        <div class="media-left meida media-middle">
                            <span><i class="f-s-50">₹</i></span>
                        </div>
                        <div class="media-body media-text-right">
                            <h2>
                                <?php 
                                    $result = mysqli_query($conn, 'SELECT SUM(total) AS value_sum FROM orders WHERE status = "delivered"'); 
                                    $row = mysqli_fetch_assoc($result); 
                                    echo $row['value_sum'];
                                ?>
                            </h2>
                            <p class="m-b-0">Total Earnings</p>
                        </div>
                    </div>
                </div>
            </div>
  
    
    <!-- Content Row -->
    <div class="row">
      <!-- Recent Orders -->
      <div class="col-lg-6 mb-4">
        <div class="card shadow">
          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Recent Orders</h6>
            <a href="orders.php" class="btn btn-sm btn-primary">View All</a>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                    <?php while($order = $recent_orders->fetch_assoc()): ?>
                      <tr class="<?= strtolower($order['status']) === 'pending' ? 'pending-order' : '' ?>">
                        <td>#<?= $order['order_id'] ?></td>
                        <td><?= htmlspecialchars($order['customer_name']) ?></td>
                        <td>₹<?= number_format($order['total'], 2) ?></td>
                        <td>
                          <span class="badge 
                            <?= strtolower($order['status']) === 'pending' ? 'bg-warning' : 
                              (strtolower($order['status']) === 'processing' ? 'bg-info' : 'bg-success') ?>">
                            <?= ucfirst($order['status']) ?>
                          </span>
                        </td>
                      </tr>
                    <?php endwhile; ?>
                 </tbody>


              </table>
            </div>
          </div>
        </div>
      </div>
      
      <!--Upcoming Reservations -->
      <div class="col-lg-6 mb-4">
         <div class="card shadow">
           <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Upcoming Reservations</h6>
            <a href="manage_reservation.php" class="btn btn-sm btn-primary">View All</a>
          </div> 
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Reservation ID</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Guests</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while($reservation = $upcoming_reservations->fetch_assoc()): ?>
                  <tr>
                    <td>#<?= $reservation['rs_id'] ?></td>
                    <td><?= htmlspecialchars($reservation['customer_name']) ?></td>
                    <td><?= date('M j, Y', strtotime($reservation['date'])) ?></td>
                    <td><?= $reservation['Guests'] ?></td>
                  </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div> 
    
    <!-- Quick Actions -->
    <div class="row">
      <div class="col-12">
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Quick Actions</h6>
          </div>
          <div class="card-body">
            <div class="row text-center">
              <div class="col-md-3 mb-3 mb-md-0">
                <a href="add_menu.php" class="btn btn-primary btn-icon-split">
                  <span class="icon text-white-50">
                    <i class="fas fa-plus"></i>
                  </span>
                  <span class="text">Add Menu Item</span>
                </a>
              </div>
              <div class="col-md-3 mb-3 mb-md-0">
                <a href="manage_menu.php" class="btn btn-success btn-icon-split">
                  <span class="icon text-white-50">
                    <i class="fas fa-edit"></i>
                  </span>
                  <span class="text">Edit Menu</span>
                </a>
              </div>
              <div class="col-md-3 mb-3 mb-md-0">
                <a href="orders.php" class="btn btn-info btn-icon-split">
                  <span class="icon text-white-50">
                    <i class="fas fa-clipboard-list"></i>
                  </span>
                  <span class="text">Process Orders</span>
                </a>
              </div>
              <!-- <div class="col-md-3">
                <a href="manage_reservation.php" class="btn btn-warning btn-icon-split">
                  <span class="icon text-white-50">
                    <i class="fas fa-calendar-check"></i>
                  </span>
                  <span class="text">Check Reservations</span> -->
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- In-page Content Frame (hidden by default, shown when a sidebar item is opened) -->
  <iframe id="contentFrame" name="contentFrame" style="display:none;width:100%;height:calc(100vh - 120px);border:0;" title="Admin Content"></iframe>
</div>

<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright &copy; Om Restaurant <?= date('Y') ?></span>
    </div>
  </div>
</footer>



</body>

<script>
  // Toggle sidebar on mobile
  document.getElementById('sidebarToggle').addEventListener('click', function() {
    document.getElementById('sidebar').classList.toggle('show');
  });
  
  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    
    if (window.innerWidth <= 992 && 
        !sidebar.contains(event.target) && 
        !sidebarToggle.contains(event.target) && 
        sidebar.classList.contains('show')) {
      sidebar.classList.remove('show');
    }
  });

  // In-page navigation: load links into iframe instead of navigating away
  (function() {
    const overviewEl = document.getElementById('dashboardOverview');
    const frameEl = document.getElementById('contentFrame');
    const sidebarEl = document.getElementById('sidebar');

    function showOverview() {
      if (frameEl) {
        frameEl.style.display = 'none';
        // Optional: clear src to stop running pages
        // frameEl.src = '';
      }
      if (overviewEl) overviewEl.style.display = '';
      setActiveLink('dashboard.php');
    }

    function loadInFrame(url) {
      if (!frameEl) return;
      if (overviewEl) overviewEl.style.display = 'none';
      frameEl.style.display = 'block';
      if (frameEl.getAttribute('src') !== url) {
        frameEl.setAttribute('src', url);
      }
    }

    function setActiveLink(href) {
      if (!sidebarEl) return;
      const links = sidebarEl.querySelectorAll('.nav-link');
      links.forEach(function(a) {
        a.classList.toggle('active', a.getAttribute('href') === href);
      });
    }

    // Intercept sidebar link clicks
    if (sidebarEl) {
      sidebarEl.addEventListener('click', function(e) {
        const a = e.target.closest('a.nav-link');
        if (!a) return;
        const href = a.getAttribute('href');
        if (!href) return;

        // Allow Logout to perform full-page navigation
        if (href === 'logout.php' || /\blogout\.php(\?|$)/i.test(href)) {
          e.preventDefault();
          window.top.location.href = href;
          return;
        }

        // Clicking Dashboard returns to overview
        if (href === 'dashboard.php' || href === '#') {
          e.preventDefault();
          showOverview();
          return;
        }

        // Load all other links into iframe
        e.preventDefault();
        setActiveLink(href);
        loadInFrame(href);
      });
    }

    // Intercept Quick Action buttons inside overview
    document.addEventListener('click', function(e) {
      const btnLink = e.target.closest('.dashboard-container a.btn');
      if (!btnLink) return;
      const href = btnLink.getAttribute('href');
      if (!href || href === '#') return;
      e.preventDefault();
      setActiveLink(href);
      loadInFrame(href);
    });

    // If page loaded with a hash like #/admin/add_menu.php, load it
    window.addEventListener('load', function() {
      try {
        const hash = decodeURIComponent(location.hash || '').replace(/^#\/?/, '');
        if (hash && /\.php(\?|$)/i.test(hash)) {
          loadInFrame(hash);
          setActiveLink(hash);
        }
      } catch (_) { /* noop */ }
    });
  })();
</script>


</html>

<?php include('includes/footer.php'); ?>