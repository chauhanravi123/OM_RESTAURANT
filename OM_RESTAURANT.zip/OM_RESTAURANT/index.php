<?php
// ... (your existing PHP code) ...
?>
<?php
// Connect to your database
$servername = "localhost"; // usually localhost
$username = "root";        // your MySQL username
$password = "";            // your MySQL password
$dbname = "om_restaurant"; // your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $number = mysqli_real_escape_string($conn, $_POST['number']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $message = mysqli_real_escape_string($conn, $_POST['message']);

  // Insert query
  $sql = "INSERT INTO contactus (name, number, email, message) VALUES ('$name', '$number', '$email', '$message')";

  if ($conn->query($sql) === TRUE) {
    // Redirect with success message
    header("Location: index.php?success=1");
    exit;
  } else {
    echo "<p style='color:red; text-align:center;'>Error: " . $conn->error . "</p>";
  }
}

$conn->close();
?>
<?php if (isset($_GET['success'])): ?>
  <p style="color: green; text-align:center;">Message Sent Successfully!</p>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>OM Restaurant</title>
  <link rel="stylesheet" href="../css/style.css" />
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
    }

    header {
      background: #333;
      color: white;
      padding: 15px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      font-size: 24px;
      font-weight: bold;
    }

    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
    }

    nav ul li {
      margin-left: 20px;
    }

    nav ul li a {
      color: white;
      text-decoration: none;
    }

    .menu-toggle {
      display: none; /* Hidden by default */
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer; /* Add cursor pointer for better UX */
    }

    #home img {
      width: 100%;
      height: auto;
      max-height: 500px;
      object-fit: cover;
      display: block;
      margin: 0 auto;
    }

    /* ✅ Card section */
    .card-section {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      padding: 40px 20px;
      background-color: #f9f9f9;
    }

    .card {
      background: white;
      width: 300px;
      margin: 20px;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .card-content {
      padding: 20px;
    }

    .card-content h3 {
      margin-top: 0;
      color: #333;
    }

    .contact-section img {
      max-width: 100%;
      height: auto;
    }

    body, html {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: sans-serif;
    }

    section {
      width: 100%;
      padding: 40px 20px;
    }

    h2 {
      text-align: center;
      margin-bottom: 40px;
    }

    .dish-cards,
    .card-section {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      max-width: 1200px;
      max-height: 100%;
      margin: auto;
    }

    .card {
      flex: 1 1 300px;
      margin-top: 1%;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s;
      max-width: 350px;
      height: 291px;
    }

    .card:hover {
      transform: scale(1.03);
    }

    .card img {
      width: 100%;
      height: auto;
      display: block;
    }

    .card-content {
      padding: 20px;
    }
    /* for mobilw view */
    @media (max-width: 768px) {
      nav ul {
        display: none;
        flex-direction: column;
        position: absolute;
        top: 60px;
        left: 0;
        width: 100%;
        background-color: #333;
        padding: 10px 0;
        z-index: 1000;
      }

      nav ul.show {
        display: flex; /* Show when toggled */
      }

      nav ul li {
        margin: 10px 0;
        text-align: center;
      }

      .menu-toggle {
        display: block;
      }
    }

    
  </style>
</head>

<body>

<header>
  <div class="logo">OM RESTAURANT</div>
    <nav id="navbar">
      <ul>
        <li><a href="#home">Home</a></li>      
        <li><a href="admin/menu.php">Menu</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="login.php">Login</a></li>
      </ul>
    </nav>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>

</header>

<main>
  <section id="home">
    <h1 style="color:blue;">Welcome to OM Restaurant</h1>
    <img src="admin/images/Restaurant.png" alt="Restaurant Image" />
  </section>

  <section class="popular-dishes">
  <h2 style="text-align:center; margin-top: 40px;">Popular Dishes of This Month</h2>
  <div class="dish-cards">
  
  </div>
</section>
        <section class="card-section">
    <div class="card">
      <img src="admin/images/gujrtitahali.jpg" alt="Gujarati Thali">
      <div class="card-content">
        <h3>Gujarati Thali</h3>
        <p>Enjoy the authentic taste of Gujarat with our delicious traditional thali.</p>
      </div>
    </div>
    <div class="card">
      <img src="admin/images/south-indian.jpg" alt="South Indian">
      <div class="card-content">
        <h3>South Indian Delights</h3>
        <p>Crispy dosas, spicy sambar and tangy chutneys — a South Indian experience!</p>
      </div>
    </div>
    <div class="card">
      <img src="admin/images/punjabi.jpg" alt="Chinese Food">
      <div class="card-content">
        <h3>Punjabi Special</h3>
        <p>From Punjabi Subji Nan,savor the Punjabi flavors you love.</p>
      </div>
    </div>
  </section>
</main>

<section id="contact" class="contact-section">
  <div class="contact-container">
    <div class="contact-image">
      <img src="admin/images/gujarati_restaurant_in_gujarat.jpg" alt="OM Restaurant">
    </div>
    <div class="contact-form">
      <h2>Contact Us</h2>
      <form action="index.php" method="post">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="tel" name="number" placeholder="Phone Number" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>
  </div>
</section>

<footer class="site-footer">
  <link rel="stylesheet" href="../css/footer.css">
  <div class="footer-content">
    <div class="footer-about">
      <h3>OM RESTAURANT</h3>
      <p>Delicious food.</p>
    </div>
    <div class="footer-links">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="admin/menu.php">Menu</a></li>
        <li><a href="reservation.php">Reservations</a></li> 
        <li><a href="#">Contact</a></li>
      </ul>
    </div>
    <div class="footer-contact-info">
      <h4>Get in Touch</h4>
      <p>📞 <a href="tel:+919876543210">+91 98765 43210</a></p>
      <p>📧 <a href="mailto:info@omrestaurant.com">info@omrestaurant.com</a></p>
      <p>📍 Raiya chokdi,150 feet Ring Road,Rajkot, Gujarat</p>
    </div>
    <div class="footer-social">
      <h4>Follow Us</h4>
      <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/facebook--v1.png"/></a>
      <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/instagram-new.png"/></a>
      <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/twitter-squared.png"/></a>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2025 OM RESTAURANT. All rights reserved. <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>
  </div>
</footer>
</body>
        <script src="../js/script.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../js/bootstrap.bundle.min.js"></script>
        <script>
        // JavaScript for form validation
        document.querySelector("form").addEventListener("submit", function(e) {
          const name = document.querySelector("input[name='name']").value.trim();
          const number = document.querySelector("input[name='number']").value.trim();
          const email = document.querySelector("input[name='email']").value.trim();
          const message = document.querySelector("textarea[name='message']").value.trim();

          const phonePattern = /^[6-9]\d{9}$/; // Indian phone number pattern
          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

          if (!name || !number || !email || !message) {
            alert("Please fill out all fields.");
            e.preventDefault();
          } else if (!phonePattern.test(number)) {
            alert("Please enter a valid 10-digit Indian phone number.");
            e.preventDefault();
          } else if (!emailPattern.test(email)) {
            alert("Please enter a valid email address.");
            e.preventDefault();
          }
        });

        // JavaScript for the mobile menu toggle
        function toggleMenu() {
          var navList = document.querySelector("#navbar ul");
          navList.classList.toggle("show");
        }

        </script>
</html>